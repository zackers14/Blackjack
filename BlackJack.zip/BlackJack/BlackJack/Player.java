
package BlackJack;

import java.util.*;

public class Player{
   
   public List<Card> hand = new ArrayList<Card>();
   // Hit or stay, default is hit.
   public boolean action = true;
   private boolean comp = false;


   public Player(boolean comp){
      this.comp = comp;
      action = true;
   }


   public void ChangePlayerAction(){
      if (action) {
         action = false;
      }
      else {
            action = true;
      }

   }

}