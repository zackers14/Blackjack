package BlackJack;

public class Card{

   private int value;
   private String suit;
   private String identifier;
   public boolean hidden;
   
   public Card(int value, int suit, String identifier){
      this.value = value;
      
      switch(suit){
         case 0: this.suit = "Spades"; break;
         case 1: this.suit = "Clubs"; break;
         case 2: this.suit = "Hearts"; break;
         case 3: this.suit = "Diamonds"; break;
      }
      this.hidden = true;
      this.identifier = identifier;
   }

}