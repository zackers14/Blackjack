
package BlackJack;

import java.util.*;

public class Deck {

   private Card[][] CurrentDeck = new Card[4][12];
   private List<Card> DealtCards = new ArrayList<Card>();

   //Deck constructor, builds the current deck with appropriate cards in the correct order
   public Deck(){
      for(int i = 0; i < 4; i++){
      
         for(int j = 0; j < 12; j++){
         
            CurrentDeck[i][j] = new Card(j+1, i, i + " " + j);
         }
      
      }
   }

   //Deals a card to a target player
   public boolean DealCard(Player player) {

       if (player.action) {
           for (int i = 0; i < 4; i++) {

               for (int j = 0; j < 12; j++) {

                   if (CurrentDeck[i][j] != null) {
                       player.hand.add(CurrentDeck[i][j]);
                       if (player.hand.size() == 1) {

                           player.hand.get(0).hidden = false;
                       }
                   }
               }

           }
           return true;
       } else {
           return false;
       }
   }

   //Shuffles the deck, switching all cards with another random card in the deck. Also adds back in dealt cards
   public Card[][] ShuffleDeck(Card[][] Current, List<Card> Dealt){
   int randomIndex1;
   int randomIndex2;
   Card currentCard;
   Card randomCard;
   int listCounter = 0;
   
      for(int i = 0; i < 4; i++){
      
         for(int j = 0; j < 12; j++){
         
            randomIndex1 = (int) Math.floor(Math.random() * 4);
            randomIndex2 = (int) Math.floor(Math.random() * 12);
            currentCard = Current[i][j];
            if (currentCard == null){
               Current[i][j] = Dealt.get(listCounter);
               currentCard = Current[i][j];
               Dealt.remove(currentCard);
            }
            randomCard = Current[randomIndex1][randomIndex2];
            Current[i][j] = randomCard;
            Current[randomIndex1][randomIndex2] = currentCard;   
         }
      }
   
   return Current;
   }
   
}