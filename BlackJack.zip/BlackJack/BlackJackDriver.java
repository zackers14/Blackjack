package BlackJack;

import java.util.Scanner;

public class BlackJackDriver{


   public static void main(String[] args){
       BlackJackDriver driver = new BlackJackDriver();
       driver.RunGame(args);


   }

    private Player Player1;
    private AI Player2;
    private Deck PlayingDeck;
    private boolean GameIsRunning = false;


   private void StartGame(){
       // First player cannot be computer controlled
       Player1 = new Player(false);
       Player2 = new AI();
       PlayingDeck = new Deck();
       PlayingDeck.ShuffleDeck();
       GameIsRunning = true;
   }

   private void RunGame (String[] args){
       Scanner sc = new Scanner(System.in);
       StartGame();
       //Deal first two cards to both players
       PlayingDeck.DealCard(Player1);
       PlayingDeck.DealCard(Player2);
       PlayingDeck.DealCard(Player1);
       PlayingDeck.DealCard(Player2);

       while (GameIsRunning) {
           if (!Player1.fold && Player1.action){
               System.out.print("Your current hand consists of: \n");
               System.out.println(Player1.getHand());
               System.out.println("The sum of cards in your hand is: " + Player1.SumHand());
               System.out.println("Would you like to draw another card?");
               String input = sc.nextLine();
               System.out.println();
               if (!(input.equals("y") || input.equals("Y"))){
                   Player1.ChangePlayerActionToStay();
               }
               else {
                   PlayingDeck.DealCard(Player1);
               }
               if (Player1.SumHand() > 21){
                   Player1.fold = true;
                   Player1.ChangePlayerActionToStay();
               }
               else if (Player1.SumHand() == 21){
                   Player1.ChangePlayerActionToStay();
                   System.out.println("Blackjack!");
               }

           }
           if (!Player2.fold && Player2.action){
               if (Player2.CalculateAction(Player2.SumHand())){
                   PlayingDeck.DealCard(Player2);
               }
               Player2.AIBust();
           }
           if (!Player1.action && !Player2.action){
               GameIsRunning = false;
           }

       }

       if ((Player1.SumHand() > Player2.SumHand() && !Player1.fold) || (!Player1.fold && Player2.fold)){
           System.out.println("You win!");
       }
       else if ((Player1.SumHand() == Player2.SumHand()) || (Player1.fold && Player2.fold)){
           System.out.println("Draw");
       }
       else {System.out.println("You lose!");}

        // End logging
       System.out.println("Player1 cards and values:");
       System.out.println(Player1.getHand());
       System.out.println("Player 1 sum: " + Player1.SumHand());

       System.out.println("Player2 cards and values:");
       System.out.println(Player2.getHand());
       System.out.println("Player 2 sum: " + Player2.SumHand());
   }

}
