package BlackJack;

/**
 * Created by ZACK MERICLE on 7/10/2017.
 */
public class AI extends Player {

    public AI(){
        this.comp = true;
    }

    public boolean CalculateAction(int sum){
        if (sum > 17){
            this.ChangePlayerActionToStay();
            return false;
        }
        return true;
    }

    public void AIBust(){
        if (this.SumHand() > 21){
            this.fold = true;
            ChangePlayerActionToStay();
        }
    }
}
